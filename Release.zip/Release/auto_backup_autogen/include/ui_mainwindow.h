/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *MenuDarkmode;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QPushButton *Button_source_folder;
    QPushButton *Button_source_files;
    QListWidget *list_source;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QPushButton *Button_dest;
    QListWidget *list_dest;
    QVBoxLayout *verticalLayout_3;
    QPushButton *Button_start;
    QPushButton *Button_view_active;
    QPushButton *Button_clear;
    QLabel *footer;
    QMenuBar *menubar;
    QMenu *menuMenu;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(609, 405);
        MainWindow->setMinimumSize(QSize(550, 300));
        MenuDarkmode = new QAction(MainWindow);
        MenuDarkmode->setObjectName(QString::fromUtf8("MenuDarkmode"));
        MenuDarkmode->setCheckable(true);
        MenuDarkmode->setChecked(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy);
        centralwidget->setMinimumSize(QSize(0, 350));
        verticalLayout_5 = new QVBoxLayout(centralwidget);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetFixedSize);
        Button_source_folder = new QPushButton(centralwidget);
        Button_source_folder->setObjectName(QString::fromUtf8("Button_source_folder"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Maximum);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(Button_source_folder->sizePolicy().hasHeightForWidth());
        Button_source_folder->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(Button_source_folder);

        Button_source_files = new QPushButton(centralwidget);
        Button_source_files->setObjectName(QString::fromUtf8("Button_source_files"));
        sizePolicy2.setHeightForWidth(Button_source_files->sizePolicy().hasHeightForWidth());
        Button_source_files->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(Button_source_files);


        verticalLayout->addLayout(horizontalLayout);

        list_source = new QListWidget(centralwidget);
        list_source->setObjectName(QString::fromUtf8("list_source"));
        list_source->setEnabled(true);
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(list_source->sizePolicy().hasHeightForWidth());
        list_source->setSizePolicy(sizePolicy3);
        list_source->setMinimumSize(QSize(0, 100));
        list_source->setBaseSize(QSize(0, 0));
        list_source->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        list_source->setDragEnabled(true);
        list_source->setResizeMode(QListView::Adjust);

        verticalLayout->addWidget(list_source);


        horizontalLayout_2->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_2);

        Button_dest = new QPushButton(centralwidget);
        Button_dest->setObjectName(QString::fromUtf8("Button_dest"));
        sizePolicy.setHeightForWidth(Button_dest->sizePolicy().hasHeightForWidth());
        Button_dest->setSizePolicy(sizePolicy);

        verticalLayout_2->addWidget(Button_dest);

        list_dest = new QListWidget(centralwidget);
        list_dest->setObjectName(QString::fromUtf8("list_dest"));
        list_dest->setEnabled(true);
        sizePolicy3.setHeightForWidth(list_dest->sizePolicy().hasHeightForWidth());
        list_dest->setSizePolicy(sizePolicy3);
        list_dest->setMinimumSize(QSize(0, 100));
        list_dest->setBaseSize(QSize(0, 0));
        list_dest->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        list_dest->setResizeMode(QListView::Adjust);

        verticalLayout_2->addWidget(list_dest);


        horizontalLayout_2->addLayout(verticalLayout_2);


        verticalLayout_4->addLayout(horizontalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        Button_start = new QPushButton(centralwidget);
        Button_start->setObjectName(QString::fromUtf8("Button_start"));
        sizePolicy1.setHeightForWidth(Button_start->sizePolicy().hasHeightForWidth());
        Button_start->setSizePolicy(sizePolicy1);

        verticalLayout_3->addWidget(Button_start);

        Button_view_active = new QPushButton(centralwidget);
        Button_view_active->setObjectName(QString::fromUtf8("Button_view_active"));
        sizePolicy1.setHeightForWidth(Button_view_active->sizePolicy().hasHeightForWidth());
        Button_view_active->setSizePolicy(sizePolicy1);

        verticalLayout_3->addWidget(Button_view_active);

        Button_clear = new QPushButton(centralwidget);
        Button_clear->setObjectName(QString::fromUtf8("Button_clear"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(Button_clear->sizePolicy().hasHeightForWidth());
        Button_clear->setSizePolicy(sizePolicy4);

        verticalLayout_3->addWidget(Button_clear);


        verticalLayout_4->addLayout(verticalLayout_3);

        footer = new QLabel(centralwidget);
        footer->setObjectName(QString::fromUtf8("footer"));
        footer->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_4->addWidget(footer);


        verticalLayout_5->addLayout(verticalLayout_4);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 609, 21));
        menuMenu = new QMenu(menubar);
        menuMenu->setObjectName(QString::fromUtf8("menuMenu"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuMenu->menuAction());
        menuMenu->addAction(MenuDarkmode);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Auto Backup", nullptr));
        MenuDarkmode->setText(QCoreApplication::translate("MainWindow", "Darkmode", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "File(s)/folder(s) to backup", nullptr));
        Button_source_folder->setText(QString());
        Button_source_files->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "Destination folder(s)", nullptr));
        Button_dest->setText(QString());
        Button_start->setText(QCoreApplication::translate("MainWindow", "Save", nullptr));
        Button_view_active->setText(QCoreApplication::translate("MainWindow", "View active backups", nullptr));
        Button_clear->setText(QCoreApplication::translate("MainWindow", "Clear lists", nullptr));
        footer->setText(QString());
        menuMenu->setTitle(QCoreApplication::translate("MainWindow", "Menu", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
