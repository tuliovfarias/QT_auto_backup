/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[40];
    char stringdata0[346];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 19), // "Get_source_explorer"
QT_MOC_LITERAL(31, 0), // ""
QT_MOC_LITERAL(32, 17), // "Get_dest_explorer"
QT_MOC_LITERAL(50, 27), // "Button_start_backup_pressed"
QT_MOC_LITERAL(78, 27), // "Button_view_backups_pressed"
QT_MOC_LITERAL(106, 18), // "Dest_path_selected"
QT_MOC_LITERAL(125, 20), // "Button_clear_pressed"
QT_MOC_LITERAL(146, 16), // "add_files_source"
QT_MOC_LITERAL(163, 16), // "const QMimeData*"
QT_MOC_LITERAL(180, 8), // "mimeData"
QT_MOC_LITERAL(189, 14), // "add_files_dest"
QT_MOC_LITERAL(204, 15), // "change_DarkMode"
QT_MOC_LITERAL(220, 18), // "remove_from_source"
QT_MOC_LITERAL(239, 16), // "remove_from_dest"
QT_MOC_LITERAL(256, 12), // "on_show_hide"
QT_MOC_LITERAL(269, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(303, 6), // "reason"
QT_MOC_LITERAL(310, 9), // "TimerSlot"
QT_MOC_LITERAL(320, 25) // "change_active_auto_backup"

    },
    "MainWindow\0Get_source_explorer\0\0"
    "Get_dest_explorer\0Button_start_backup_pressed\0"
    "Button_view_backups_pressed\0"
    "Dest_path_selected\0Button_clear_pressed\0"
    "add_files_source\0const QMimeData*\0"
    "mimeData\0add_files_dest\0change_DarkMode\0"
    "remove_from_source\0remove_from_dest\0"
    "on_show_hide\0QSystemTrayIcon::ActivationReason\0"
    "reason\0TimerSlot\0change_active_auto_backup"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   98,    2, 0x08,    1 /* Private */,
       3,    0,   99,    2, 0x08,    2 /* Private */,
       4,    0,  100,    2, 0x08,    3 /* Private */,
       5,    0,  101,    2, 0x08,    4 /* Private */,
       6,    0,  102,    2, 0x08,    5 /* Private */,
       7,    0,  103,    2, 0x08,    6 /* Private */,
       8,    1,  104,    2, 0x08,    7 /* Private */,
      11,    1,  107,    2, 0x08,    9 /* Private */,
      12,    0,  110,    2, 0x08,   11 /* Private */,
      13,    0,  111,    2, 0x08,   12 /* Private */,
      14,    0,  112,    2, 0x08,   13 /* Private */,
      15,    1,  113,    2, 0x08,   14 /* Private */,
      18,    0,  116,    2, 0x08,   16 /* Private */,
      19,    0,  117,    2, 0x08,   17 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->Get_source_explorer(); break;
        case 1: _t->Get_dest_explorer(); break;
        case 2: _t->Button_start_backup_pressed(); break;
        case 3: _t->Button_view_backups_pressed(); break;
        case 4: _t->Dest_path_selected(); break;
        case 5: _t->Button_clear_pressed(); break;
        case 6: _t->add_files_source((*reinterpret_cast< std::add_pointer_t<const QMimeData*>>(_a[1]))); break;
        case 7: _t->add_files_dest((*reinterpret_cast< std::add_pointer_t<const QMimeData*>>(_a[1]))); break;
        case 8: _t->change_DarkMode(); break;
        case 9: _t->remove_from_source(); break;
        case 10: _t->remove_from_dest(); break;
        case 11: _t->on_show_hide((*reinterpret_cast< std::add_pointer_t<QSystemTrayIcon::ActivationReason>>(_a[1]))); break;
        case 12: _t->TimerSlot(); break;
        case 13: _t->change_active_auto_backup(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QMimeData *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QMimeData *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QSystemTrayIcon::ActivationReason, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
